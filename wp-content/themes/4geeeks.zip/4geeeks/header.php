<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <title><?php wp_title(); ?></title>
    <!-- Definir viewport para dispositivos web móviles -->
    <meta name="viewport" content="width=device-width, minimum-scale=1">
    <link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/favicon.ico" />
    <link rel="stylesheet" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
    <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
</head>
<body>
    <div class="wrapper">
        <header>
            <div class="row">
					<div class="span3">
						<a href="index.php">
							<img src="images/logo.png">
						</a>
					</div>
					<div class="span4 pull-right">
						<div class="social">
							<a href="#">
								<img src="/images/mail.png">
							</a>
							<a href="#">
								<img src="images/facebook.png">
							</a>
							<a href="#">
								<img src="images/twitter.png">
							</a>
							<a href="#">
								<img src="images/youtube.png">
							</a>
							<a href="#">
								<img src="images/linkedin.png">
							</a>
						</div>
					</div>
				</div>
            <h1><a href="<?php echo get_option('home'); ?>"><?php bloginfo('name'); ?></a></h1>
            <hr>
            <?php wp_nav_menu( array('menu' => 'Main', 'container' => 'nav' )); ?>
        </header>