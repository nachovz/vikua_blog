<?php get_header(); ?>
    <section id="main">

    </section> <!-- Fin de main -->
<?php  get_sidebar()?>
<?php get_footer(); ?>