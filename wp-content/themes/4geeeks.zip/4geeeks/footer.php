<footer>
    <p>&amp;copy; <?php bloginfo('name'); ?>, <?=date('Y');?>. Mi primer tema de WP.</p>
</footer>
</div> <!-- Fin de wrapper -->
<?php wp_footer(); ?>
</body>
</html>