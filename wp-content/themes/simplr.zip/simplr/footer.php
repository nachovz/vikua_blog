        </div>
	</div>
		<footer>
			<div class="container">
				<img class="footer-border" src="wp-content/themes/simplr/images/footer-border.png">
				<a href="<?php bloginfo('url'); ?>">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-1.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-1.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-1.png"' >

					</div>
				</a>
				<img src="wp-content/themes/simplr/images/footer-divider.png">
				<a href="#">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-2.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-2.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-2.png"'>
					</div>
				</a>
				<img src="wp-content/themes/simplr/images/footer-divider.png">
				<a href="<?php bloginfo('url'); ?>/?page_id=46">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-3.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-3.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-3.png"'>
					</div>
				</a>
				<img src="wp-content/themes/simplr/images/footer-divider.png">
				<a href="<?php bloginfo('url'); ?>/?page_id=48 ">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-4.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-4.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-4.png"'>
					</div>
				</a>
				<img src="wp-content/themes/simplr/images/footer-divider.png">
				<a href="<?php bloginfo('url'); ?>/?page_id=7">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-5.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-5.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-5.png"'>
					</div>
				</a>
				<img src="wp-content/themes/simplr/images/footer-divider.png">
				<a href="<?php bloginfo('url'); ?>/?page_id=50 ">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-6.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-6.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-6.png"'>
					</div>
				</a>
				<img src="wp-content/themes/simplr/images/footer-divider.png">
				<a href="<?php bloginfo('url'); ?>/?page_id=68">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-7.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-7.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-7.png"'>
					</div>
				</a>
				<img src="wp-content/themes/simplr/images/footer-divider.png">
				<a href="<?php bloginfo('url'); ?>/?page_id=78 ">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-8.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-8.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-8.png"'>
					</div>
				</a>
				<img src="wp-content/themes/simplr/images/footer-divider.png">
				<a href="<?php bloginfo('url'); ?>/?page_id=52">
					<div class="btn-footer">
						<img src="wp-content/themes/simplr/images/btn-off-9.png" onmouseover='this.src="wp-content/themes/simplr/images/btn-on-9.png"' onmouseout='this.src="wp-content/themes/simplr/images/btn-off-9.png"'>
					</div>
				</a>
			</div>
		</footer>
        <script src="<?php bloginfo('stylesheet_directory'); ?>/js/jquery.js"></script>
    	<script src="<?php bloginfo('stylesheet_directory'); ?>/js/bootstrap.js"></script>
		<script type="text/javascript">
			$('.carousel').carousel()
		</script>
<?php wp_footer() // Do not remove; helps plugins work ?>


</body><!-- end transmission -->
</html>